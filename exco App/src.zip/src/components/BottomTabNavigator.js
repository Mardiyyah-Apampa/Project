// Import the createBottomTabNavigator function from the @react-navigation/bottom-tabs package
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';

// Import the BiodataScreen and ClinicalRecordScreen component from its file location
import BiodataScreen from '../components/BiodataScreen';
import ClinicalRecordScreen from '../components/ClinicalRecordScreen';

// Create a Tab Navigator instance using the createBottomTabNavigator function
const Tab = createBottomTabNavigator();

// Define a functional component called BottomTabNavigator
function BottomTabNavigator() {
  return (
    // Wrap the Tab Navigator in a NavigationContainer, which is required to manage the navigation tree
    <NavigationContainer>
      {/* Call the Tab Navigator method to define the bottom tab navigation structure */}
      <Tab.Navigator
        // Set the initial route to be the Biodata screen when the app loads
        initialRouteName="Biodata"
        // Set the tab bar active tint color to the clinic's primary color (yellow)
        screenOptions={{ tabBarActiveTintColor: '#FFD700' }}
      >
        {/* Define the first tab screen for Biodata, linking to the BiodataScreen component */}
        <Tab.Screen name="Biodata" component={BiodataScreen} />
        {/* Define the second tab screen for Clinical Record, linking to the ClinicalRecordScreen component */}
        <Tab.Screen name="Clinical Record" component={ClinicalRecordScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

// Export the BottomTabNavigator component as the default export
export default BottomTabNavigator;
