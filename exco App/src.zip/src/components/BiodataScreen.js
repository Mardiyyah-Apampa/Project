// Import necessary modules from React and React Native
import React, { useState } from 'react'; // Importing React and the useState hook
import { View, TextInput, StyleSheet, Text, ScrollView, SafeAreaView } from 'react-native'; // Importing necessary components from react-native
import Header from '../components/Header'; // Importing the Header component from the correct path

// Define the BiodataScreen functional component
const BiodataScreen = () => {
  // Initialize state using the useState hook for managing form inputs
  const [form, setForm] = useState({
    firstName: '',
    surname: '',
    middleName: '',
    dob: '',
    address: '',
    registrationDate: '',
    matriculationnumber: '',
  });

  // Function to handle changes in the input fields
  const handleInputChange = (field, value) => {
    setForm({ ...form, [field]: value }); // Update the specific field in the form state
  };

  // Return the JSX to render the UI
  return (
    // SafeAreaView to ensure content is rendered within the safe area boundaries of the device
    <SafeAreaView style={styles.container}>
      {/* Header component, assumed to be a custom component */}
      <Header />
      {/* ScrollView to enable scrolling for the form inputs */}
      <ScrollView contentContainerStyle={styles.formContainer}>
        {/* Input field for First Name */}
        <Text style={styles.label}>First Name</Text>
        <TextInput
          style={styles.input} // Apply styles to the TextInput
          value={form.firstName} // Bind the value of the TextInput to the form state
          onChangeText={(text) => handleInputChange('firstName', text)} // Call handleInputChange when the text changes
        />
        {/* Input field for Surname */}
        <Text style={styles.label}>Surname</Text>
        <TextInput
          style={styles.input}
          value={form.surname}
          onChangeText={(text) => handleInputChange('surname', text)} // Update state on text change
        />
        {/* Input field for Middle Name */}
        <Text style={styles.label}>Middle Name</Text>
        <TextInput
          style={styles.input}
          value={form.middleName}
          onChangeText={(text) => handleInputChange('middleName', text)} // Update state on text change
        />
        {/* Input field for Date of Birth */}
        <Text style={styles.label}>Date of Birth</Text>
        <TextInput
          style={styles.input}
          value={form.dob}
          onChangeText={(text) => handleInputChange('dob', text)} // Update state on text change
        />
        {/* Input field for Home Address */}
        <Text style={styles.label}>Home Address</Text>
        <TextInput
          style={styles.input}
          value={form.address}
          onChangeText={(text) => handleInputChange('address', text)} // Update state on text change
        />
        {/* Input field for Date of Registration */}
        <Text style={styles.label}>Date of Registration</Text>
        <TextInput
          style={styles.input}
          value={form.registrationDate}
          onChangeText={(text) => handleInputChange('registrationDate', text)} // Update state on text change
        />
        {/* Input field for Matriculation number */}
        <Text style={styles.label}>Matriculation Number (e.g. _334942894723)</Text>
        <TextInput
          style={styles.input}
          value={form.matriculationnumber}
          onChangeText={(text) => handleInputChange('matriculationnumber', text)} // Update state on text change
          />
      </ScrollView>
    </SafeAreaView>
  );
};

// Define the styles using StyleSheet.create
const styles = StyleSheet.create({
  container: {
    flex: 1, // Makes the container take up the full height of the screen
    backgroundColor: '#FBFBA7', // White background for clarity
  },
  formContainer: {
    padding: 20, // Adds padding inside the form container
  },
  label: {
    marginTop: 15, // Adds a margin above each label
    fontSize: 16, // Sets the font size of the label text
    fontWeight: 'bold', // Makes the label text bold
    color: '#333', // Dark text color for labels
  },
  input: {
    borderWidth: 1, // Sets the border width of the TextInput
    borderColor: '#cccccc', // Sets the border color of the TextInput
    padding: 10, // Adds padding inside the TextInput
    marginTop: 5, // Adds a margin above each TextInput
    borderRadius: 5, // Rounded corners for the TextInput
  },
});

// Export the BiodataScreen component as the default export
export default BiodataScreen;
