import React from 'react'; // Importing React from the 'react' library
import { View, Image, StyleSheet } from 'react-native'; // Importing necessary components and utilities from 'react-native'

// Defining a functional component named Header
const Header = () => (
  // The View component acts as a container for the header
  <View style={styles.header}> 
    {/* Image component to display the logo. The source is a local image file */}
    <Image source={require('../../assets/logo.png')} style={styles.logo} />
  </View>
);

// Defining styles using StyleSheet.create
const styles = StyleSheet.create({
  // Styles for the header container
  header: {
    alignItems: 'center', // Center the children horizontally
    marginVertical: 20,   // Add vertical margins of 20 units
  },
  // Styles for the logo image
  logo: {
    width: 100,  // Set the width of the logo to 100 units
    height: 100, // Set the height of the logo to 100 units
  },
});

// Exporting the Header component as the default export
export default Header;
