import React, { useState } from 'react';
import { View, TextInput, StyleSheet, Text, ScrollView, SafeAreaView } from 'react-native';
import Header from '../components/Header'; // Ensure this path is correct


const ClinicalRecordScreen = () => {
  const [form, setForm] = useState({
    clinicDate: '',
    ailment: '',
    medicine: '',
    procedure: '',
    nextAppointment: '',
  });


  const handleInputChange = (field, value) => {
    setForm({ ...form, [field]: value });
  };


  return (
    <SafeAreaView style={styles.container}>
      <Header />
      <ScrollView contentContainerStyle={styles.formContainer}>
        <Text style={styles.label}>Clinic Date</Text>
        <TextInput
          style={styles.input}
          value={form.clinicDate}
          onChangeText={(text) => handleInputChange('clinicDate', text)}
        />
        <Text style={styles.label}>Nature of Ailment</Text>
        <TextInput
          style={styles.input}
          value={form.ailment}
          onChangeText={(text) => handleInputChange('ailment', text)}
        />
        <Text style={styles.label}>Medicine Prescribed</Text>
        <TextInput
          style={styles.input}
          value={form.medicine}
          onChangeText={(text) => handleInputChange('medicine', text)}
        />
        <Text style={styles.label}>Procedure Undertaken</Text>
        <TextInput
          style={styles.input}
          value={form.procedure}
          onChangeText={(text) => handleInputChange('procedure', text)}
        />
        <Text style={styles.label}>Date of Next Appointment</Text>
        <TextInput
          style={styles.input}
          value={form.nextAppointment}
          onChangeText={(text) => handleInputChange('nextAppointment', text)}
        />
      </ScrollView>
    </SafeAreaView>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FBFBA7', // White background for clarity
  },
  formContainer: {
    padding: 20,
  },
  label: {
    marginTop: 15,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333', // Dark text color for labels
  },
  input: {
    borderWidth: 1,
    borderColor: '#cccccc',
    padding: 10,
    marginTop: 5,
    borderRadius: 5, // Rounded corners
  },
});


export default ClinicalRecordScreen;
